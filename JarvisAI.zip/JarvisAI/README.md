# JARVIS AI (v1)
1. Install Android Studio, open this folder, let Gradle sync (it creates the wrapper).
2. Build > Build APK(s) (debug) -> app/build/outputs/apk/debug/app-debug.apk
3. On your phone: enable Developer options + USB debugging, plug in, press Run. Or copy the APK and allow "install unknown apps".
4. Open Settings in the app, paste a Gemini API key (https://aistudio.google.com/apikey), check the model name.
Voice commands: open <app>, open <site.com>, open wifi/bluetooth/sound/display settings, set a timer for N minutes, what time is it, battery level.
