package com.jarvis.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.util.Locale

enum class St(val label: String) { Idle("IDLE"), Listening("LISTENING"), Thinking("THINKING"), Speaking("SPEAKING") }

val Bg = Color(0xFF050B14); val Cyan = Color(0xFF00E5FF); val Panel = Color(0xFF0C1A2B)

class Assistant(val ctx: Context) {
    val prefs = Prefs(ctx)
    val msgs = mutableStateListOf<Msg>().apply { addAll(prefs.load()) }
    var st by mutableStateOf(St.Idle)
    var err by mutableStateOf<String?>(null)
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    init {
        tts = TextToSpeech(ctx) { ok ->
            if (ok == TextToSpeech.SUCCESS) tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { if (st == St.Speaking) st = St.Idle }
                @Deprecated("") override fun onError(id: String?) { if (st == St.Speaking) st = St.Idle }
            })
        }
    }
    fun speak(t: String) {
        if (!prefs.speak || tts == null) { st = St.Idle; return }
        tts?.language = Locale.forLanguageTag(prefs.lang); st = St.Speaking
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j")
    }
    fun stopSpeaking() { tts?.stop(); if (st == St.Speaking) st = St.Idle }
    fun stopListening() { rec?.cancel(); rec?.destroy(); rec = null; if (st == St.Listening) st = St.Idle }
    fun listen(scope: CoroutineScope) {
        err = null; stopSpeaking()
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { err = "Speech recognition isn't available on this device."; return }
        rec?.destroy(); rec = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}; override fun onPartialResults(p: Bundle?) {}; override fun onEvent(t: Int, p: Bundle?) {}
            override fun onError(e: Int) { st = St.Idle; if (e != SpeechRecognizer.ERROR_CLIENT) err = if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) "I didn't catch that." else "Speech error ($e)." }
            override fun onResults(r: Bundle?) {
                st = St.Idle
                r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { send(it, scope) }
            }
        })
        rec?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.lang))
        st = St.Listening
    }
    fun send(raw: String, scope: CoroutineScope) {
        val t = raw.trim(); if (t.isEmpty()) return
        err = null; msgs.add(Msg("user", t))
        val cmd = Router.handle(ctx, t)
        if (cmd != null) { msgs.add(Msg("assistant", cmd)); prefs.save(msgs); speak(cmd); return }
        st = St.Thinking
        scope.launch {
            try {
                val r = withContext(Dispatchers.IO) { Gemini.chat(prefs.key, prefs.model, msgs.toList()) }
                msgs.add(Msg("assistant", r)); speak(r)
            } catch (e: Exception) { err = e.message ?: "Unknown error"; st = St.Idle }
            prefs.save(msgs)
        }
    }
    fun clear() { msgs.clear(); prefs.save(msgs) }
    fun destroy() { rec?.destroy(); tts?.shutdown() }
}

class MainActivity : ComponentActivity() {
    private lateinit var a: Assistant
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); a = Assistant(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel)) { Screen(a) } }
    }
    override fun onStop() { super.onStop(); a.stopListening() }
    override fun onDestroy() { super.onDestroy(); a.destroy() }
}

@Composable
fun Screen(a: Assistant) {
    var settings by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().imePadding().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("J.A.R.V.I.S", color = Cyan, fontSize = 26.sp, letterSpacing = 6.sp)
                Text(a.st.label, color = Cyan.copy(alpha = .7f), fontSize = 12.sp, letterSpacing = 3.sp)
            }
            TextButton(onClick = { settings = !settings }) { Text(if (settings) "Back" else "Settings", color = Cyan) }
        }
        if (settings) SettingsPane(a) else Chat(a)
    }
}

@Composable
fun ColumnScope.Chat(a: Assistant) {
    val scope = rememberCoroutineScope(); val ctx = LocalContext.current
    val list = rememberLazyListState(); var input by remember { mutableStateOf("") }
    LaunchedEffect(a.msgs.size) { if (a.msgs.isNotEmpty()) list.animateScrollToItem(a.msgs.size - 1) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) a.listen(scope) else a.err = "Microphone permission denied. You can still type."
    }
    LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (a.msgs.isEmpty()) item { Text("Try: \"open settings\", \"open wifi settings\", \"open youtube\", \"open example.com\", \"set a timer for 5 minutes\", \"what time is it\", \"battery level\" — or ask anything.", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(8.dp)) }
        items(a.msgs) { m ->
            val me = m.role == "user"
            Box(Modifier.fillMaxWidth(), contentAlignment = if (me) Alignment.CenterEnd else Alignment.CenterStart) {
                Text(m.text, color = Color.White, modifier = Modifier.widthIn(max = 300.dp)
                    .border(1.dp, if (me) Cyan else Cyan.copy(alpha = .3f), RoundedCornerShape(12.dp))
                    .background(if (me) Cyan.copy(alpha = .12f) else Panel, RoundedCornerShape(12.dp)).padding(10.dp))
            }
        }
        if (a.st == St.Thinking) item { Row { CircularProgressIndicator(Modifier.size(18.dp), color = Cyan, strokeWidth = 2.dp); Spacer(Modifier.width(8.dp)); Text("Thinking…", color = Cyan) } }
    }
    a.err?.let { Text(it, color = Color(0xFFFF6B6B), modifier = Modifier.padding(vertical = 4.dp)) }
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(1f, 1.25f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "s")
    val active = a.st == St.Listening
    Box(Modifier.align(Alignment.CenterHorizontally).padding(8.dp).size(110.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.size(84.dp).scale(if (active) pulse else 1f).alpha(if (active) .35f else .15f).background(Cyan, CircleShape))
        Box(Modifier.size(76.dp).border(2.dp, Cyan, CircleShape).background(Panel, CircleShape).clickable {
            if (active) a.stopListening()
            else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) a.listen(scope)
            else perm.launch(Manifest.permission.RECORD_AUDIO)
        }, contentAlignment = Alignment.Center) { Text(if (active) "STOP" else "MIC", color = Cyan, fontSize = 14.sp, letterSpacing = 2.sp) }
    }
    if (a.st == St.Speaking) OutlinedButton(onClick = { a.stopSpeaking() }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Stop speaking", color = Cyan) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Type a message") }, singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { a.send(input, scope); input = "" }))
        Spacer(Modifier.width(8.dp))
        Button(onClick = { a.send(input, scope); input = "" }, enabled = input.isNotBlank() && a.st != St.Thinking) { Text("Send") }
    }
}

@Composable
fun SettingsPane(a: Assistant) {
    var key by remember { mutableStateOf(a.prefs.key) }; var model by remember { mutableStateOf(a.prefs.model) }
    var lang by remember { mutableStateOf(a.prefs.lang) }; var speak by remember { mutableStateOf(a.prefs.speak) }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(key, { key = it; a.prefs.key = it }, Modifier.fillMaxWidth(), label = { Text("Gemini API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
        Text("Warning: a key stored in a client-side app can't be fully protected. Use a restricted, low-quota key, and revoke it if the phone is lost. It is stored only on this device and sent only to Google's Gemini API.", color = Color(0xFFFFB74D), fontSize = 12.sp)
        OutlinedTextField(model, { model = it; a.prefs.model = it }, Modifier.fillMaxWidth(), label = { Text("Gemini model name") }, singleLine = true)
        OutlinedTextField(lang, { lang = it; a.prefs.lang = it }, Modifier.fillMaxWidth(), label = { Text("Language tag (e.g. en-US, es-ES)") }, singleLine = true)
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(speak, { speak = it; a.prefs.speak = it }); Spacer(Modifier.width(8.dp)); Text("Read replies aloud", color = Color.White) }
        OutlinedButton(onClick = { a.clear() }) { Text("Clear conversation history", color = Cyan) }
        Text("Privacy: typed or spoken text and recent chat history are sent to Google's Gemini API to generate replies. Voice is converted to text by Android's speech service (which may be processed by your device's speech provider). JARVIS never listens in the background; it only listens after you tap the mic. Phone commands (opening apps, settings, browser, timers) run on-device and aren't sent to Gemini. No live web search: the AI can't see current events.", color = Color.Gray, fontSize = 12.sp)
    }
}
