package com.jarvis.ai

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.DateFormat
import java.util.Date

data class Msg(val role: String, val text: String)

class Prefs(c: Context) {
    private val sp = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    var key: String get() = sp.getString("key", "")!!; set(v) { sp.edit().putString("key", v.trim()).apply() }
    // Default is only a starting value; change it in Settings if Google retires it.
    var model: String get() = sp.getString("model", "gemini-2.5-flash")!!; set(v) { sp.edit().putString("model", v.trim()).apply() }
    var lang: String get() = sp.getString("lang", "en-US")!!; set(v) { sp.edit().putString("lang", v.trim()).apply() }
    var speak: Boolean get() = sp.getBoolean("speak", true); set(v) { sp.edit().putBoolean("speak", v).apply() }
    fun load(): List<Msg> = try {
        val a = JSONArray(sp.getString("hist", "[]")); (0 until a.length()).map { Msg(a.getJSONObject(it).getString("r"), a.getJSONObject(it).getString("t")) }
    } catch (e: Exception) { emptyList() }
    fun save(m: List<Msg>) {
        val a = JSONArray(); m.takeLast(200).forEach { a.put(JSONObject().put("r", it.role).put("t", it.text)) }
        sp.edit().putString("hist", a.toString()).apply()
    }
}

object Gemini {
    fun chat(key: String, model: String, hist: List<Msg>): String {
        if (key.isBlank()) throw Exception("Add your Gemini API key in Settings first.")
        if (model.isBlank()) throw Exception("Set a model name in Settings.")
        val contents = JSONArray()
        hist.takeLast(20).forEach {
            contents.put(JSONObject().put("role", if (it.role == "user") "user" else "model")
                .put("parts", JSONArray().put(JSONObject().put("text", it.text))))
        }
        val sys = "You are JARVIS, a concise, helpful phone assistant. You have no live web access and cannot perform phone actions yourself; never claim to have done an action or to know current events you can't know."
        val body = JSONObject().put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/${Uri.encode(model)}:generateContent")
            .openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 60000; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            if (code !in 200..299) throw Exception(when (code) {
                400 -> "Request rejected (400). Check the API key and model name."
                401, 403 -> "Invalid or unauthorized API key."
                404 -> "Model '$model' not found. Change it in Settings."
                429 -> "Quota or rate limit reached. Try again later."
                else -> "Gemini error (HTTP $code)."
            })
            val txt = c.inputStream.bufferedReader().readText()
            val parts = JSONObject(txt).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            val out = (0 until (parts?.length() ?: 0)).joinToString("") { parts!!.getJSONObject(it).optString("text") }
            return out.ifBlank { "I got an empty response (it may have been blocked)." }
        } catch (e: java.io.IOException) {
            throw Exception("Network error. Check your connection.")
        } finally { c.disconnect() }
    }
}

object Router {
    /** Returns a result message if the text was a supported command, else null (goes to AI). */
    fun handle(c: Context, text: String): String? {
        val s = text.lowercase().trim().trimEnd('.', '!', '?')
        fun go(i: Intent, ok: String) = try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i); ok }
            catch (e: Exception) { "Couldn't do that: ${e.message ?: "no app can handle it"}" }
        if ("setting" in s) {
            val map = listOf("wifi" to Settings.ACTION_WIFI_SETTINGS, "wi-fi" to Settings.ACTION_WIFI_SETTINGS,
                "bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS, "sound" to Settings.ACTION_SOUND_SETTINGS,
                "display" to Settings.ACTION_DISPLAY_SETTINGS, "battery" to Settings.ACTION_BATTERY_SAVER_SETTINGS)
            val hit = map.firstOrNull { it.first in s }
            if (hit != null) return go(Intent(hit.second), "Opened ${hit.first} settings.")
            if (s.startsWith("open") || s.startsWith("show")) return go(Intent(Settings.ACTION_SETTINGS), "Opened settings.")
        }
        if (Regex("what('s| is) the (time|date)|what time|what day|today's date").containsMatchIn(s))
            return "It's ${DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.SHORT).format(Date())}."
        if ("battery" in s && ("level" in s || "percent" in s || "how much" in s || "what" in s)) {
            val p = (c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            return if (p in 0..100) "Battery is at $p percent." else "Battery level isn't available on this device."
        }
        Regex("timer for (\\d+) ?(second|sec|minute|min|hour)").find(s)?.let {
            val n = it.groupValues[1].toInt(); val u = it.groupValues[2]
            val secs = n * if (u.startsWith("h")) 3600 else if (u.startsWith("m")) 60 else 1
            return go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS timer").putExtra(AlarmClock.EXTRA_SKIP_UI, false),
                "Handed a $n $u timer to your clock app. Please confirm it there.")
        }
        Regex("^(open|launch|start|go to|visit) (.+)$").find(s)?.let { m ->
            val t = m.groupValues[2].removePrefix("the ").trim()
            if (t.startsWith("http") || (Regex("^[\\w-]+(\\.[\\w-]+)+(/\\S*)?$").matches(t)))
                return go(Intent(Intent.ACTION_VIEW, Uri.parse(if (t.startsWith("http")) t else "https://$t")), "Opening $t in your browser.")
            if (m.groupValues[1] in listOf("go to", "visit")) return null
            val pm = c.packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val app = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == t }
                ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(t) }
                ?: return "I couldn't find an installed app called \"$t\"."
            val li = pm.getLaunchIntentForPackage(app.activityInfo.packageName) ?: return "\"$t\" can't be launched."
            return go(li, "Opening ${app.loadLabel(pm)}.")
        }
        return null
    }
}
